#!/bin/bash

# AutoClicker Debian Package Build Script
# This script builds a .deb package for the AutoClicker application using stdeb

set -e  # Exit on any error

echo "=== AutoClicker Debian Package Builder ==="
echo

# Check if stdeb is installed
if ! python3 -c "import stdeb" 2>/dev/null; then
    echo "Error: stdeb is not installed or not properly configured."
    echo "Install stdeb with: pip install stdeb"
    exit 1
fi

# Check if required files exist
required_files=("setup.py" "stdeb.cfg" "requirements.txt")
for file in "${required_files[@]}"; do
    if [ ! -f "$file" ]; then
        echo "Error: Required file '$file' not found."
        exit 1
    fi
done

echo "✓ All required files found"

# Clean previous build artifacts
echo "Cleaning previous build artifacts..."
rm -rf build/ dist/ deb_dist/ *.egg-info/
echo "✓ Cleaned build artifacts"

# Build the source distribution
echo "Building source distribution..."
python3 setup.py sdist
echo "✓ Source distribution built"

# Build the Debian package
echo "Building Debian package..."

# Try different stdeb approaches
DEB_BUILT=false

# Method 1: Try py2dsc if available
if command -v py2dsc >/dev/null 2>&1; then
    echo "Using py2dsc to build Debian package..."
    if py2dsc dist/autoclicker-*.tar.gz; then
        echo "✓ Source package built using py2dsc"

        # Now build the binary package
        echo "Building binary Debian package..."
        cd deb_dist/autoclicker-1.0.0
        if dpkg-buildpackage -us -uc; then
            echo "✓ Binary Debian package built"
            DEB_BUILT=true
            mv ../python3-autoclicker_*.deb ../ 2>/dev/null || true
        fi
        cd ../..
    fi
fi

# Method 2: Try stdeb.main if not already built
if [ "$DEB_BUILT" = false ]; then
    echo "Using stdeb.main to build Debian package..."
    if python3 -c "
import sys
sys.path.insert(0, '.')
from stdeb.main import main
import sys
sys.argv = ['stdeb', 'sdist_dsc']
try:
    main()
    print('SUCCESS')
except SystemExit as e:
    if e.code == 0:
        print('SUCCESS')
    else:
        print('FAILED')
except Exception as e:
    print('FAILED:', str(e))
" 2>/dev/null | grep -q "SUCCESS"; then
        echo "✓ Debian package built using stdeb.main"
        DEB_BUILT=true
    fi
fi

# Method 3: Manual dpkg-buildpackage approach
if [ "$DEB_BUILT" = false ]; then
    echo "Using manual dpkg-buildpackage approach..."
    mkdir -p deb_build
    cd deb_build

    # Extract the source
    tar -xzf ../dist/autoclicker-*.tar.gz
    cd autoclicker-*

    # Create basic debian directory structure
    mkdir -p debian
    cat > debian/control << EOF
Source: autoclicker
Section: utils
Priority: optional
Maintainer: Your Name <your.email@example.com>
Build-Depends: debhelper (>= 9), python3, python3-setuptools
Standards-Version: 3.9.6

Package: python3-autoclicker
Architecture: all
Depends: python3, python3-pyautogui, python3-opencv, python3-pytesseract, python3-pil, python3-numpy, python3-pygame, python3-pynput, python3-keyboard
Description: AutoClicker for Ubuntu - Finds and clicks on user-defined images or text
 Long description:
  This package provides an AutoClicker tool for Ubuntu that can find and click
  on user-defined images or text on the screen. It supports various modes including
  image template matching, OCR text recognition, and mixed modes.
EOF

    cat > debian/rules << 'EOF'
#!/usr/bin/make -f

%:
	dh $@ --with python3

override_dh_auto_install:
	python3 setup.py install --root=debian/python3-autoclicker --install-layout=deb
EOF
    chmod +x debian/rules

    cat > debian/changelog << EOF
autoclicker (1.0.0-1) unstable; urgency=low

  * Initial Debian package

 -- Your Name <your.email@example.com>  $(date -R)
EOF

    cat > debian/compat << EOF
9
EOF

    # Build the package
    if dpkg-buildpackage -us -uc; then
        echo "✓ Debian package built using dpkg-buildpackage"
        DEB_BUILT=true
        mv ../python3-autoclicker_*.deb ../deb_dist/ 2>/dev/null || mkdir -p ../deb_dist && mv ../python3-autoclicker_*.deb ../deb_dist/
    fi

    cd ..
    rm -rf autoclicker-*
    cd ..
fi

if [ "$DEB_BUILT" = false ]; then
    echo "Note: Could not build .deb package automatically."
    echo "The source distribution has been built successfully in dist/"
    echo
    echo "To manually create a .deb package, you can:"
    echo "1. Install additional Debian packaging tools:"
    echo "   sudo apt install py2dsc dpkg-dev debhelper"
    echo "2. Run: py2dsc dist/autoclicker-*.tar.gz"
    echo "3. Or use the manual dpkg-buildpackage approach above"
fi

# Show the results
echo
echo "=== Build Results ==="
if [ -d "deb_dist" ] && [ "$(ls -A deb_dist/*.deb 2>/dev/null)" ]; then
    echo "Debian packages created in deb_dist/:"
    ls -la deb_dist/*.deb
    echo
    echo "To install the package locally:"
    echo "sudo dpkg -i deb_dist/*.deb"
    echo "sudo apt-get install -f  # Fix any missing dependencies"
elif [ -d "dist" ] && [ "$(ls -A dist/*.tar.gz 2>/dev/null)" ]; then
    echo "Source packages created in dist/:"
    ls -la dist/*.tar.gz
    echo
    echo "The source package can be used for:"
    echo "- pip install dist/*.tar.gz"
    echo "- Further packaging with stdeb or other tools"
else
    echo "No packages found. Build may have failed."
    exit 1
fi

echo
echo "=== Build Complete ==="
echo "The .deb package is ready for distribution or installation."
