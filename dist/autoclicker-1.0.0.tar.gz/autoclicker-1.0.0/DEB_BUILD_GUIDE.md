# Debian Package Build Guide for AutoClicker

This guide explains how to build a Debian (.deb) package for the AutoClicker application using the provided build script.

## Prerequisites

Before building the Debian package, ensure you have the following installed:

### Required Dependencies

1. **Python 3** (3.8 or higher)
   ```bash
   sudo apt update
   sudo apt install python3 python3-pip
   ```

2. **stdeb** - Python to Debian package converter
   ```bash
   pip3 install stdeb
   ```

3. **Build dependencies** (for the AutoClicker itself)
   ```bash
   pip3 install -r requirements.txt
   ```

4. **Debian packaging tools** (optional, for advanced usage)
   ```bash
   sudo apt install debhelper dh-python
   ```

## Project Structure

The following files are required for building the Debian package:

- `setup.py` - Python package configuration
- `stdeb.cfg` - stdeb configuration file
- `requirements.txt` - Python dependencies
- `build_deb.sh` - Build script (created for this guide)

## Building the Debian Package

### Method 1: Using the Build Script (Recommended)

1. **Navigate to the project directory**
   ```bash
   cd /path/to/AutoClicker
   ```

2. **Run the build script**
   ```bash
   ./build_deb.sh
   ```

   The script will:
   - Check for required dependencies and files
   - Clean previous build artifacts
   - Build the source distribution
   - Create the Debian package
   - Display the results

3. **Check the output**
   ```
   === Build Results ===
   Debian packages created in deb_dist/:
   -rw-r--r-- 1 user user 27202 Sep 20 16:53 deb_dist/python3-autoclicker_1.0.0-1_all.deb

   To install the package locally:
   sudo dpkg -i deb_dist/*.deb
   sudo apt-get install -f  # Fix any missing dependencies
   ```

### Method 2: Manual Build (Advanced)

If you prefer to build manually or need more control:

1. **Clean previous builds**
   ```bash
   rm -rf build/ dist/ deb_dist/ *.egg-info/
   ```

2. **Build source distribution**
   ```bash
   python3 setup.py sdist
   ```

3. **Build Debian package using stdeb directly**
   ```bash
   # Option 1: Using py2dsc (if available)
   py2dsc dist/autoclicker-*.tar.gz

   # Option 2: Using stdeb.main
   python3 -m stdeb.main sdist_dsc

   # Option 3: Using setup.py (if bdist_deb is available)
   python3 setup.py bdist_deb
   ```

## Installing the Package

### Local Installation

1. **Install the .deb package**
   ```bash
   sudo dpkg -i deb_dist/python3-autoclicker_*.deb
   ```

2. **Fix any missing dependencies**
   ```bash
   sudo apt-get install -f
   ```

3. **Verify installation**
   ```bash
   autoclicker --help
   autoclicker-gui --help
   ```

### Uninstalling

```bash
sudo dpkg -r python3-autoclicker
```

## Package Contents

The Debian package includes:

- **Binary executables:**
  - `/usr/bin/autoclicker` - Command-line interface
  - `/usr/bin/autoclicker-gui` - Graphical user interface

- **Python modules:**
  - `/usr/lib/python3/dist-packages/autoclicker.py`
  - `/usr/lib/python3/dist-packages/autoclicker_gui.py`

- **Data files:**
  - `/usr/share/autoclicker/` - Configuration files and scripts

- **Documentation:**
  - `/usr/share/doc/python3-autoclicker/` - Debian package documentation

## Configuration

The package uses stdeb configuration from `stdeb.cfg`:

```ini
[DEFAULT]
Depends: python3, python3-pyautogui, python3-opencv, python3-pytesseract, python3-pil, python3-numpy, python3-pygame, python3-pynput, python3-keyboard
Suggests: scrot, imagemagick
Package: autoclicker
Debian-Version: 1
Section: utils
Priority: optional
Architecture: all
```

## Troubleshooting

### Common Issues

1. **stdeb not found**
   ```bash
   pip3 install stdeb
   ```

2. **Missing dependencies**
   ```bash
   sudo apt-get install -f
   ```

3. **Permission denied**
   ```bash
   chmod +x build_deb.sh
   ```

4. **Build fails**
   - Check that all required files exist
   - Ensure Python 3.8+ is installed
   - Verify all dependencies are installed

### Debug Information

To get more verbose output during building:

```bash
python3 setup.py bdist_deb --verbose
```

## Distribution

Once built, the `.deb` file in `deb_dist/` can be:

- Installed locally as shown above
- Uploaded to a Debian repository
- Distributed to other Ubuntu/Debian users
- Submitted to Ubuntu PPAs (Personal Package Archives)

## Version Management

To update the package version:

1. Update the version in `setup.py`
2. Update the Debian version in `stdeb.cfg` if needed
3. Rebuild the package

## Advanced Usage

### Custom Build Options

You can pass additional options to stdeb:

```bash
python3 setup.py bdist_deb --maintainer="Your Name <your.email@example.com>"
```

### Building for Different Architectures

The current configuration builds for `Architecture: all` (architecture-independent). For architecture-specific builds, modify `stdeb.cfg`.

### Integration with CI/CD

The build script can be integrated into CI/CD pipelines:

```yaml
# Example GitHub Actions step
- name: Build Debian Package
  run: ./build_deb.sh
```

## Support

If you encounter issues:

1. Check the troubleshooting section above
2. Verify all prerequisites are met
3. Check the stdeb documentation: https://github.com/astraw/stdeb
4. Review the AutoClicker project documentation

## License

This build guide and the AutoClicker application are provided under the MIT License.
